from django.http import HttpResponse
from django.template import loader
import sqlite3
from django.conf import settings

#db_path = os.path.join("..", "DB.sqlite3")
#conn = sqlite3.connect(db_path)
db_path = settings.DATABASES["default"]["NAME"]
conn = sqlite3.connect(db_path)
cursor = conn.cursor()
cursor.execute("SELECT * FROM insights_recommendation")
rows = cursor.fetchall()

def insights(request):
    template = loader.get_template("insights/index.html")
    context = {
        "rows": rows,
    }
    return HttpResponse(template.render(context, request))

conn.close()