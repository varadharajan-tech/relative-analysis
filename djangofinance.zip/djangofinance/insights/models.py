from django.db import models


class Recommendation(models.Model):
    company_name = models.CharField(max_length=200)
    decision = models.CharField(max_length=200)
    def __str__(self):
        return self.company_name