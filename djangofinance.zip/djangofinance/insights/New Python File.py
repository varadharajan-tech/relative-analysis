import os, sqlite3
db_path = os.path.join("..", "DB.sqlite3")
conn = sqlite3.connect(db_path)
cursor = conn.cursor()
cursor.execute("SELECT * FROM insights_recommendation")
rows = cursor.fetchall()

for row in rows:
    print(row[0], row[1], row[2])

conn.close()